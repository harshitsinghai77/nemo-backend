__version__ = "0.1.0"
from dotenv import load_dotenv

load_dotenv()
